from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parents[1] / "src"))
from drowsiness import DrowsinessMonitor

monitor = DrowsinessMonitor()
assert monitor.update(0.32, 0.25).state == "ALERT"
monitor = DrowsinessMonitor(closed_frames=3, yawn_frames=50, history_size=1)
for _ in range(3):
    status = monitor.update(0.12, 0.2)
assert status.state == "DROWSY"
monitor = DrowsinessMonitor(closed_frames=50, yawn_frames=3, history_size=1)
for _ in range(3):
    status = monitor.update(0.32, 0.9)
assert status.state == "ATTENTION"
print("smoke tests: PASS")
